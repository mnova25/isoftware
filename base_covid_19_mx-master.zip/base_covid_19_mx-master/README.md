# base_covid_19_mx
Datos Abiertos - Dirección General de Epidemiología, SSA, México. Covid-19
